Document Generation Run
Date Generated: 2023-12-04.11-24-48
Workspace ID: 6661
Workspace Data File: null
Template Zip File: /home/immport/file_system/temporary/DataUpload.Documentation.1001/ImmPortTemplates.6661.2023-12-04.11-24-48.zip

Starting Document Generation
  Generating Excel Template Spreadsheets
  Generating Txt Template Spreadsheets
  Generating PDF File
  Generating Json Files
  Generating Json Schema Files
Completed Document Generation
