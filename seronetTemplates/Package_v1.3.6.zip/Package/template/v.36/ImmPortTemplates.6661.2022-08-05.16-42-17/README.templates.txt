Document Generation Run
Date Generated: 2022-08-05.16-42-18
Workspace ID: 6661
Workspace Data File: null
Template Zip File: /home/immport/file_system/temporary/DataUpload.Documentation.1002/ImmPortTemplates.6661.2022-08-05.16-42-18.zip

Starting Document Generation
  Generating Excel Template Spreadsheets
  Generating Txt Template Spreadsheets
  Generating PDF File
  Generating Json Files
  Generating Json Schema Files
Completed Document Generation
