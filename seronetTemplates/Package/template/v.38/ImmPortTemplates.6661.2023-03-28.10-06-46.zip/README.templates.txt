Document Generation Run
Date Generated: 2023-03-28.10-06-47
Workspace ID: 6661
Workspace Data File: null
Template Zip File: /home/immport/file_system/temporary/DataUpload.Documentation.1001/ImmPortTemplates.6661.2023-03-28.10-06-47.zip

Starting Document Generation
  Generating Excel Template Spreadsheets
  Generating Txt Template Spreadsheets
  Generating PDF File
  Generating Json Files
  Generating Json Schema Files
Completed Document Generation
